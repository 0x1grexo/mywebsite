# Keskkonnakangelane - küsimusmäng
# Autor = "Gregor Opmann"
# Eesmärk: hinnata kasutaja igapäevaste valikute põhjal, kui keskkonnasõbralik ta on.

import logging
import time

# loggimine
logging.basicConfig(filename='keskkonnakangelane_tulemused.txt', level=logging.INFO, format='%(asctime)s - %(message)s')

def tutvustus():
    roheline = "\033[92m"
    reset = "\033[0m"
    print(roheline + "Tere tulemast mängu 'Keskkonnakangelane'!" + reset)
    print(roheline + "Sa teed iga päev valikuid, mis mõjutavad keskkonda." + reset)
    print(roheline + "Vasta ausalt, ja saad teada, kui roheline inimene sa oled." + reset)
    print("-------------------------------------------------------")

def tee_valik(küsimus, variandid):
    print("\n" + küsimus)
    for i in range(len(variandid)):
        print(str(i + 1) + ". " + variandid[i])
    vastus = input("Vali tegevuse number: ")
    return vastus

def arvuta_punktid(valikud):
    punktid = 0
    mõjud = [2, 0, -1, 3, -2, 1]
    uued_mõjud = [2, -1, 3, 1, -2]
    mõjud.extend(uued_mõjud)

    for v in valikud:
        try:
            nr = int(v) - 1
            if nr >= 0 and nr < len(mõjud):
                punktid = punktid + mõjud[nr]
        except:
            print("Vigane sisend, punkte ei lisatud.")
    return punktid

def hinnang(punktid, nimi):
    roheline = "\033[92m"
    reset = "\033[0m"
    print(roheline + "\n--- TULEMUS ---" + reset)
    print("Mängija: " + nimi)
    if punktid >= 6:
        print(roheline + "Sa oled tõeline keskkonnakangelane! 🌍" + reset)
        logging.info("Mängija: " + nimi + " - TULEMUS: Sa oled tõeline keskkonnakangelane!")
    elif punktid >= 3:
        print(roheline + "Sa oled üsna teadlik, kuid arenguruumi on veel." + reset)
        logging.info("Mängija: " + nimi + " - TULEMUS: Sa oled üsna teadlik, kuid arenguruumi on veel.")
    else:
        print(roheline + "Oi-oi-oi... sinu keskkonnamõju võiks olla väiksem! Proovi teha paremaid valikuid." + reset)
        logging.info("Mängija: " + nimi + " - TULEMUS: Oi-oi-oi... sinu keskkonnamõju võiks olla väiksem! Proovi teha paremaid valikuid.")
    print("Tulemus on salvestatud samasse kausta sinu arvutil, kus mängu fail asub ('keskkonnakangelane_tulemused.txt')" )

#animatsioon enne tulemust
def laadimisanimatsioon():
    roheline = "\033[92m"
    reset = "\033[0m"
    etapid = [
        roheline + "Arvutan sinu keskkonnamõju..." + reset,
        "█▒▒▒▒▒▒▒▒▒ 10%",
        "█████▒▒▒▒▒ 50%",
        "██████████ 100%",
        roheline + "Valmis!" + reset
    ]
    viivitus = 1
    for i in range(len(etapid)):
        print(etapid[i])
        if i < len(etapid) - 1:
            time.sleep(viivitus)
            viivitus = viivitus + 1

def mäng():
    roheline = "\033[92m"
    reset = "\033[0m"
    tutvustus()
    nimi = input("Sisesta oma nimi: ")
    valikud = []
    küsimused = [
        (roheline + "Kuidas lähed kooli/tööle?" + reset, ["Bussiga", "Autoga üksi", "Jalgrattaga", "Jalgsi"]),
        (roheline + "Mida sööd lõunaks?" + reset, ["Liha", "Taimetoit", "Kiirtoit"]),
        (roheline + "Kuidas käitud prügiga?" + reset, ["Sorteerin prügi", "Viskan kõik ühte kasti"]),
        (roheline + "Kuidas tarbid vett?" + reset, ["Sulgen kraani hammaste pesemisel", "Lasen vee lihtsalt joosta"]),
        (roheline + "Kas kasutad korduvkasutatavat pudelit?" + reset, ["Jah", "Ei"]),
        (roheline + "Kuidas liigelda linnas?" + reset, ["Bussiga", "Jalgrattaga", "Takso või sõidujagamine", "Isiklik auto"]),
        (roheline + "Kuidas suhtud riidekottide kasutamisse?" + reset, ["Kasutan alati korduvkasutatud kotti", "Kasutan tihti plastikust kotti", "Kasutan ainult paberkotti"]),
        (roheline + "Kuidas suhtud energiatootmisse kodus?" + reset, ["Kasutan päikesepaneele või taastuvenergiat", "Kasutan elektrit ainult vajadusel, olen energiatõhus", "Ei hooli energiatootmisest"]),
        (roheline + "Kuidas käitud toidujääkide ja ülejääkide osas?" + reset, ["Püüan vältida raiskamist ja komposteerin", "Viskan ülejäägid lihtsalt prügikasti", "Annab toidujäägid loomadele"]),
        (roheline + "Kas ostad mahetoitu või kohalikke tooteid?" + reset, ["Jah, eelistan mahetoitu ja kohalikku toodangut", "Ostsin vahel, kui hind on soodne", "Ei, eelistan odavamaid tooteid, olen harjunud supermarketite toiduga"])
    ]
    for q in küsimused:
        vastus = tee_valik(q[0], q[1])
        valikud.append(vastus)
    punktid = arvuta_punktid(valikud)
    #animatsioon enne tulemust
    laadimisanimatsioon()
    hinnang(punktid, nimi)
    logging.info("Mängija: " + nimi)
    logging.info("Vastused: " + ', '.join(valikud))
    logging.info("Kogutud punktid: " + str(punktid))
    logging.info("------------------------------\n")

mäng()
time.sleep(10)
exit()
#https://docs.python.org/3/library/logging.html
#https://jakob-bagterp.github.io/colorist-for-python/ansi-escape-codes/introduction/