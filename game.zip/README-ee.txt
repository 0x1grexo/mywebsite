Tere!


Siin on minu enda koostatud Python mäng. See on minu ProgeStart 2025 lõpuprojekt.


Gregor Opmann 2026