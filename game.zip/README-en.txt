Hello!

This is a Python game developed by me. It's my ProgeStart course final project.

Gregor Opmann 2026